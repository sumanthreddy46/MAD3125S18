package com.jk.sirra;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class ReceiptActivity extends AppCompatActivity {

    TextView txtCarPlate, txtAmount, txtDateTime , txtLot, txtSpot;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receipt);

        SharedPreferences sp = getSharedPreferences("com.jk.sirra.shared", Context.MODE_PRIVATE);

        txtDateTime = findViewById(R.id.txtDateTime);
        txtDateTime.setText(sp.getString("DateTime","Data Missing"));

        txtCarPlate = findViewById(R.id.txtCarPlate);
        txtCarPlate.setText(sp.getString("CarPlate","Data Missing"));

        txtLot = findViewById(R.id.txtLot);
        txtLot.setText("Lot: " + sp.getString("Lot","Data Missing"));

        txtSpot = findViewById(R.id.txtSpot);
        txtSpot.setText("Spot: " + sp.getString("Spot", "Data Missing"));

        txtAmount = findViewById(R.id.txtAmount);
        txtAmount.setText(" Amount:$" + String.valueOf(sp.getInt("Amount", 0)));

    }
}

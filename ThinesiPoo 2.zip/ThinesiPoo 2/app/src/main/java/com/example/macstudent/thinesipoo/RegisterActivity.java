package com.example.macstudent.thinesipoo;

import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class RegisterActivity extends AppCompatActivity implements View.OnClickListener {
    Button btnRegister;
    EditText edtName;
    EditText edtPhone;
    EditText edtEmail;
    EditText edtPassword;
    TextView txtdob;

    DBhelper dbHelper;
    SQLiteDatabase db;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        btnRegister = findViewById(R.id.btnRegister);
        edtName = findViewById(R.id.edtname);
        edtPhone = findViewById(R.id.edtphone);
        edtEmail = findViewById(R.id.edtemail);
        edtPassword = findViewById(R.id.edtpassword);
        txtdob = findViewById(R.id.txtdob);
        txtdob.setOnClickListener(this);

        btnRegister.setOnClickListener(this);
        dbHelper = new DBhelper(this );


    }

    @Override
    public void onClick(View v){
        if(v.getId() == btnRegister.getId()){
//            String data = edtName.getText().toString()+ "\n" + edtPhone.getText().toString()+ "\n"
//                    + edtEmail.getText().toString()+ "\n" + edtPassword.getText().toString();
//            Toast.makeText(this,data, Toast.LENGTH_LONG).show();
            insertData();
            displayData();
            finish();
            startActivity(new Intent(this,LoginActivity.class));

        }else if (v.getId() == txtdob.getId()){
            Calendar calendar = Calendar.getInstance();
            new DatePickerDialog(this, datepickerListerner,calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH+1),calendar.get(Calendar.DAY_OF_MONTH) ).show();

        }

    }

    DatePickerDialog.OnDateSetListener datepickerListerner = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year, int month, int day) {
            String date = String.valueOf(month)+ "/" + String.valueOf(day)+ "/" + String.valueOf(year);
            txtdob.setText(date);
        }
    };
    private void insertData () {
        try{
            ContentValues cv = new ContentValues();
            cv.put("Name",edtName.getText().toString());
            cv.put("Phone",edtPhone.getText().toString());
            cv.put("Email",edtEmail.getText().toString());
            cv.put("Password",edtPassword.getText().toString());
            cv.put("DOB",txtdob.getText().toString());

            db = dbHelper.getWritableDatabase();
            db.insert("UserInfo", null, cv);
        }catch(Exception e){
            Log.e("RegisterActivity",e.getMessage());
        }finally{

        }
    }
    private void displayData(){
        try{
            db =dbHelper.getReadableDatabase();
            String columns[] = { "Name","Phone","Email","Password","DOB"};

            Cursor cursor = db.query("UserInfo", columns, null , null,
                    null,null,null  );

            while (cursor.moveToNext()){
                String userData = cursor.getString(cursor.getColumnIndex("Name"));
                userData += "\n"+ cursor.getString(cursor.getColumnIndex("Phone"));
                userData += "\n"+ cursor.getString(cursor.getColumnIndex("Email"));
                userData += "\n"+ cursor.getString(cursor.getColumnIndex("Password"));
                userData += "\n"+ cursor.getString(cursor.getColumnIndex("DOB"));

                Toast.makeText(this, userData, Toast.LENGTH_LONG).show();
            }

        }catch(Exception e){
            Log.e("RegisterActivity",e.getMessage());
        }finally {
            db.close();
        }

    }

}

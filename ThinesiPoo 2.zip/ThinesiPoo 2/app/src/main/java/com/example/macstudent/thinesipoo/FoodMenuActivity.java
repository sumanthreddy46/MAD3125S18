package com.example.macstudent.thinesipoo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class FoodMenuActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnApt;
    Button btnMc;
    Button btnBv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_menu);
        btnApt = findViewById(R.id.btnApt);
        btnApt.setOnClickListener(this);
        btnMc = findViewById(R.id.btnMc);
        btnMc.setOnClickListener(this);
        btnBv = findViewById(R.id.btnBv);
        btnBv.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        if(v.getId() == btnApt.getId()) {
            Intent homeIntent = new Intent(this, AppetizerActivity.class);
            startActivity(homeIntent);
        }else if(v.getId() == btnMc.getId()) {
            Intent homeIntent = new Intent(this, McActivity.class);
            startActivity(homeIntent);

        }else if(v.getId() == btnBv.getId()) {
            Intent homeIntent = new Intent(this, BvActivity.class);
            startActivity(homeIntent);


        }
    }
}
